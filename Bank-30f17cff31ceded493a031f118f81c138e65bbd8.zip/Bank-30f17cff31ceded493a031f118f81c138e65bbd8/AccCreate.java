public class AccCreate {
    private String accHolderName;
    private String accNumber;
    private double balance;
    
    public AccCreate(String accHolderName, String accNumber, double balance) {
        this.accHolderName = accHolderName;
        this.accNumber = accNumber;
        this.balance = balance;
    }
    
    // Getters.
    public String getAccHolderName() {
        return accHolderName;
    }
    
    public String getAccNumber() {
        return accNumber;
    }
    
    public double getBalance() {
        return balance;
    }
    
    // Deposit money into the account.
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    // Withdraw money from the account.
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
}
