import java.util.HashMap;

public class UserDatabase {
    // In-memory storage for accounts using a HashMap.
    // The key is the account number, and the value is the AccCreate object.
    private static HashMap<String, AccCreate> accounts = new HashMap<>();
    
    /**
     * Adds a new account to the database.
     * @param account The account to be added.
     * @return true if the account was added successfully, false if an account with the same number exists.
     */
    public static boolean addAccount(AccCreate account) {
        if (accounts.containsKey(account.getAccNumber())) {
            return false; // Account already exists.
        }
        accounts.put(account.getAccNumber(), account);
        return true;
    }
    
    /**
     * Retrieves an account based on the account number.
     * @param accNumber The account number to search for.
     * @return The account if found; otherwise, null.
     */
    public static AccCreate getAccount(String accNumber) {
        return accounts.get(accNumber);
    }
}
