public class App {
    public static void main(String[] args) {
        // Add 3 default user accounts.
        UserDatabase.addAccount(new AccCreate("Alice", "A001", 1000.0));
        UserDatabase.addAccount(new AccCreate("Bob", "B001", 1500.0));
        UserDatabase.addAccount(new AccCreate("Charlie", "C001", 2000.0));
        
        // Start the user interface.
        UserInterface ui = new UserInterface();
        ui.start();
    }
}
