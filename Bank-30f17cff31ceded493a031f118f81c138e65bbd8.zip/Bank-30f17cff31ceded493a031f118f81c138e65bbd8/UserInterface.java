import java.util.Scanner;

public class UserInterface {
    private Scanner scanner = new Scanner(System.in);

    public void start() {
        while (true) {
            System.out.println("\n=== Welcome to Our Banking App ===");
            System.out.println("1. Sign in");
            System.out.println("2. Sign up");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    signIn();
                    break;
                case 2:
                    signUp();
                    break;
                case 3:
                    System.out.println("Exiting the application. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
    
    // Sign in: Ask for the account number and, if found, send the user to the user menu.
    private void signIn() {
        System.out.print("Enter your account number: ");
        String accNumber = scanner.nextLine();
        AccCreate account = UserDatabase.getAccount(accNumber);
        if (account == null) {
            System.out.println("Account not found. Please sign up first.");
        } else {
            System.out.println();
            System.out.println("Welcome, " + account.getAccHolderName() + "!");
            System.out.println("Your current balance: " + account.getBalance());
            userMenu(account);
        }
    }
    
    // Sign up: Create a new account and automatically sign in the user.
    private void signUp() {
        System.out.print("Enter account holder name: ");
        String name = scanner.nextLine();
        System.out.print("Enter desired account number: ");
        String accNumber = scanner.nextLine();
        System.out.print("Enter initial deposit amount: ");
        double balance = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        
        // Create a new account.
        AccCreate account = new AccCreate(name, accNumber, balance);
        
        // Attempt to add the account to the database.
        boolean success = UserDatabase.addAccount(account);
        if (success) {
            System.out.println("Account created successfully!");
            System.out.println("Automatically signing you in...");
            System.out.println("Welcome, " + account.getAccHolderName() + "!");
            System.out.println("Your current balance: " + account.getBalance());
            userMenu(account);
        } else {
            System.out.println("Account creation failed. An account with that number may already exist.");
        }
    }
    
    // User menu: After sign in, offer money transfer and logout options.
    private void userMenu(AccCreate account) {
        while (true) {
            System.out.println("\n--- User Menu ---");
            System.out.println("1. Transfer Money");
            System.out.println("2. Logout");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            if (choice == 1) {
                transferMoney(account);
            } else if (choice == 2) {
                System.out.println("Logging out...");
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
    // Money transfer: Allow the current user to transfer money to another user.
    private void transferMoney(AccCreate sender) {
        System.out.println();
        System.out.print("Enter recipient account number: ");
        String recipientAcc = scanner.nextLine();
        AccCreate recipient = UserDatabase.getAccount(recipientAcc);
        if (recipient == null) {
            System.out.println("Recipient not found.");
            return;
        }
        System.out.print("Enter amount to transfer: ");
        double amount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        
        if (amount <= 0) {
            System.out.println("Amount must be positive.");
            return;
        }
        if (sender.getBalance() < amount) {
            System.out.println("Insufficient funds.");
            return;
        }
        
        // Perform the transfer.
        sender.withdraw(amount);
        recipient.deposit(amount);
        System.out.println();
        System.out.println("Transfer successful.");
        System.out.println();
        System.out.println("Your new balance: " + sender.getBalance());
        
    }
}
